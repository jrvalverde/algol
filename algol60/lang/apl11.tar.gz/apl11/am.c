#include "apl.h"

/*	The following code is so system-dependent that it was moved to
 *	a separate file.  It conditions the terminal for APL mode if called
 *	with a non-zero argument, or returns it to its normal state if called
 *	with a zero argument.
 *
 *	I ripped all of this out -- it was old, and didn't really apply to
 *	my situation.  Maybe someday it will be appropriate to put something
 *	back in here -- MEC
 */

aplmod(n)
{
}
